/**
 * 
 */
/**
 * 
 */
module Game2D {
	requires java.desktop;
}